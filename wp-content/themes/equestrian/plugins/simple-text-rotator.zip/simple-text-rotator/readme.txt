Simple Text Rotator - WordPress Shortcode

Simple Text Rotator is a beautiful and elegant text rotation solution via WordPress shortcodes. Attract your visitors attention by animating the key words of your business in a few seconds and without any programming skills. Your visitor’s attention will be exactly where you want it to be in seconds.


Features:
- Easy to use
- Unlimited Color Options
- 7 Text Effects
- Works anywhere

Shortcode Usage:
[simple-text-rotator animation=“” separator=“” speed=“”][/simple-text-rotator]
- Animation: Choose one of the seven animations available: dissolve, fade, flip, flipUp, flipCube, flipCubeUp, spin
- Separator: Choose a character as separator. Any character is allowed. Example: “|” , “,” , “/“ , “;” . Default is: “|”
- Speed: Choose the animation speed in milliseconds. Default is: 2000
	
Installation:
	Upload the plugin then activate it.
